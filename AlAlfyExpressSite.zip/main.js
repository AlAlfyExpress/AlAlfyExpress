import React from "react";
import ReactDOM from "react-dom/client";
import AlAlfyExpressWebsite from "./website.js";
import "./style.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<AlAlfyExpressWebsite />);
