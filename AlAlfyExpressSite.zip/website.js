export default function AlAlfyExpressWebsite() {
  return (
    React.createElement("div", {className: "bg"}, "موقع الألفي إكسبريس (نسخة مبسطة)")
  );
}
